Funcionalidades do sistema:

Um velho bruxo está entrando na era moderna e precisa atualizar sua loja para o presente, com isso ele contratou vários aprendizes para catalogar no seu site os itens que eles encontram nas suas aventuras. 

Usuários cadastrados entram nesse site para cadastrar seus itens.

---------------------

Autenticação de usuários:

- Cadastro de conta
- Login e logout
- Senhas armazenadas com hash
- Páginas protegidas para usuários autenticados

------------------

CRUD de itens mágicos:

- Create: 
- Cadastrar um item
- Nome do item 
- Valor do item 
- Tipo do item 
- Local da descoberta do item foi encontrado 
- Quantidade de itens 
- Nome de quem descobriu 
- Peso do item 
- Características especiais do item
- Imagem do item

------------------------------

- Read: 
- listar e visualizar os itens

- Update: 
- Editar um item

- Delete: 
- Excluir um item

----------------------------

Painel administrativo:

- Quantidade de poções cadastradas
- Valor total do estoque
- Poções com estoque baixo
- Busca por nome e filtro por categoria

-------------------

shadcn ui